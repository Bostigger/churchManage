<?php


 $conn = mysqli_connect("localhost","root","","churchman") or die("error");


 ?>
