
	<div class="row-fluid">
			<div class="span12"></div>
				  <div class="row-fluid">
						<div class="span10">
							<h4 style="color:white;">LOGO CAN BE HERE</h4>
						<!-- <img class="index_logo"  alt="Church logo will be here" > -->
						</div>
						<div class="span12">
							<div class="motto">
							<p></p>
							<p></p>
							</div>
						</div>
				  </div>
    </div>
